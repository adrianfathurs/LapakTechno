package com.example.lapaksmart;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {


    private static final Object Url = "www.google.com";
    Button btnbeli;
    private RecyclerView rvRecycleview;
    private ArrayList<Smartphone> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvRecycleview = findViewById(R.id.recycle_viewMain);
        rvRecycleview.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rvRecycleview.setLayoutManager(layoutManager);
        list.addAll(SmartphoneData.getListData());
        showRecyclerList();


    }

    private void showRecyclerList() {
        rvRecycleview.setLayoutManager(new LinearLayoutManager(this));
        ListAdaptersmart smartphoneadapter = new ListAdaptersmart(list);
        rvRecycleview.setAdapter(smartphoneadapter);

    }

    





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }

    private void setMode(int itemId) {
        switch (itemId) {
            case R.id.action_list:
                break;
            case R.id.action_grid:
                break;
            case R.id.action_cardview:
                break;
        }
    }
}
