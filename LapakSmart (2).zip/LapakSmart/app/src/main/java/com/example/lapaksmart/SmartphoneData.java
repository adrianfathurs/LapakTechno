package com.example.lapaksmart;

import java.util.ArrayList;

public class SmartphoneData {
public static String [][]data=new String[][]{
        {"Samsung A8","Rp 5.600.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHU0owGJnzmpRLABry1huVBjRk66TfshJ65tC05iu_c7lhExgE"},
        {"Samsung J6 plus","Rp 3.200.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRx8TOx_PNJnuTy9OXEUOJSXB-3ss_lYrYPcNiY_8CxMZcU0NnkEw"},
        {"Samsung S8","Rp 8.300.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxWimzMq01Y10aAsDIxCUXP371Il9PVCsDywK81Wfrp0Np7I6z"},
        {"Samsung A40","Rp 2.400.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcAQecoLs67YvM__zDccL6OmvAUe3F3u0vYesT67CA2pixhFAA"},
        {"Samsung A10","Rp 10.000.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmpuh75YnEbMzWLbERrUqCkava3HXHFYyNi2xYsR3LUdujJzsz"},
        {"Samsung S9","Rp 9.700.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQIH1oHJoXb7sLWF8XBtbCVa0zBza7FAYcpwANBJHSXHC_xJarI"},
        {"Samssung A30","Rp 4.500.000,00","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIAxUJMlDRk7kO5ERrm4ZFK8j-do2Hib2wJcWAVnHNKXILltv7"},
};
 public static ArrayList<Smartphone> getListData()
 {
ArrayList<Smartphone>list=new ArrayList<>();
    for(String []aData:data)
    {
        Smartphone smartphone=new Smartphone();
        smartphone.setNama(aData[0]);
        smartphone.setHarga(aData[1]);
        smartphone.setPhoto(aData[2]);
        list.add(smartphone);
    }
    return list;
 }
}

