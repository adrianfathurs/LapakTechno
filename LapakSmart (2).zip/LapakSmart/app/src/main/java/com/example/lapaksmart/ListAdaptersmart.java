package com.example.lapaksmart;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import static android.support.v4.content.ContextCompat.startActivity;

public class ListAdaptersmart extends RecyclerView.Adapter<ListAdaptersmart.CategoryViewHolder> {
    MainActivity mainActivity;
    private ArrayList<Smartphone> listsmart;
    private Context context;
    public ListAdaptersmart(ArrayList<Smartphone> list) {
        this.listsmart = list;

    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.itemsmart2, viewGroup, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CategoryViewHolder categoryViewHolder, int i) {

        Smartphone smartphone = listsmart.get(i);
        Glide.with(categoryViewHolder.itemView.getContext())
                .load(smartphone.getPhoto())
                .apply(new RequestOptions().override(90, 90))
                .into(categoryViewHolder.imgPhoto);
        categoryViewHolder.tvName.setText(smartphone.getNama());
        categoryViewHolder.tvHarga.setText(smartphone.getHarga());

        categoryViewHolder.btnbeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String data = listsmart.get(categoryViewHolder.getAdapterPosition()).getNama();

                Toast.makeText(categoryViewHolder.itemView.getContext(), "Buy " +
                        listsmart.get(categoryViewHolder.getAdapterPosition()).getNama(), Toast.LENGTH_SHORT).show();

        }

        });

        categoryViewHolder.btnspesifikasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(categoryViewHolder.itemView.getContext(), "Spesifikasi " +
                        listsmart.get(categoryViewHolder.getAdapterPosition()).getNama(), Toast.LENGTH_SHORT).show();

            }

        });

    }


    @Override
    public int getItemCount() {
        return listsmart.size();
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {

        ImageView imgPhoto;
        TextView tvName, tvHarga;
        Button btnbeli, btnspesifikasi;



        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            context=itemView.getContext();
            imgPhoto = itemView.findViewById(R.id.imgphotos);
            tvName = itemView.findViewById(R.id.Nama_handphone);
            tvHarga = itemView.findViewById(R.id.harga);
            btnspesifikasi = itemView.findViewById(R.id.btnspesification);
            btnbeli = itemView.findViewById(R.id.btnbuy);
            //////////////////////////////////
            btnbeli.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    Intent move=new Intent(mainActivity,coba.class);
                    context.startActivity(move);
                }
            });
            ///////////////////////////////////

        }
    }





}
